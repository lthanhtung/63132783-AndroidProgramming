package thi.lethanhtung_63132783.dethi2;


public class LandScape {
    String TieuDe;
    String TenAnh;

    public LandScape(String tieuDe, String tenAnh) {
        TieuDe = tieuDe;
        TenAnh = tenAnh;
    }

    public String getTieuDe() {
        return TieuDe;
    }

    public void setTieuDe(String tieuDe) {
        TieuDe = tieuDe;
    }

    public String getTenAnh() {
        return TenAnh;
    }

    public void setTenAnh(String tenAnh) {
        TenAnh = tenAnh;
    }
}
